package br.com.senai.urbanswift;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrbanswiftApplication {

	public static void main(String[] args) {
		SpringApplication.run(UrbanswiftApplication.class, args);
	}

}
